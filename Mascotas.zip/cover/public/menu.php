<header class="mb-auto">
    <div>
      <h3 class="float-md-start mb-0">Mascotas</h3>
      <nav class="nav nav-masthead justify-content-center float-md-end">
        <a class="nav-link fw-bold py-1 px-0 " aria-current="page" href="index.php">Inicio</a>
        <a class="nav-link fw-bold py-1 px-0" href="registrar.php">Registrar</a>
        <a class="nav-link fw-bold py-1 px-0" href="eliminar.php">Eliminar</a>
        <a class="nav-link fw-bold py-1 px-0" href="actualizar.php">Actualizar</a>
        <a class="nav-link fw-bold py-1 px-0" href="mostrar.php">Mostrar</a>
      </nav>
    </div>
  </header>