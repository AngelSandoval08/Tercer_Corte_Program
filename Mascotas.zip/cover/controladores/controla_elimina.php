<?php
require "../config/conexion.php";

$id = $_POST ["id"];

$sql ="DELETE FROM animales 
WHERE id = ".$id."
";

if ($dbh ->query($sql)) {
   echo "mascota eliminada";
}else {
    echo "error";
}

?>