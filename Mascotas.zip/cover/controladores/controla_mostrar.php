<?php

require "../config/conexion.php";


$sql = "SELECT ID, nombre, dueno 

FROM animales 
WHERE 1";

foreach ($dbh ->query($sql) as $row) {
    $nombre =$row[1];
    $dueno = $row ["dueno"];

    echo "Nombre de la mascota: ".$nombre." -Dueño: ".$dueno."<br>";

}

?>
